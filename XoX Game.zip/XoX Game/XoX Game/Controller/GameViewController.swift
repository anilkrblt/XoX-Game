import UIKit

class GameViewController: UIViewController {

    // MARK: - Model
    var gameBrain: GameBoardBrain!

    // MARK: - IBOutlets
    @IBOutlet weak var player2Avatar: UIImageView!
    @IBOutlet weak var player2Name:   UILabel!
    @IBOutlet weak var player2Symbol: UILabel!
    @IBOutlet weak var player2Score:  UILabel!

    @IBOutlet weak var player1Avatar: UIImageView!
    @IBOutlet weak var player1Name:   UILabel!
    @IBOutlet weak var player1Symbol: UILabel!
    @IBOutlet weak var player1Score:  UILabel!

    @IBOutlet weak var boardView: UIView!

    // MARK: - Local State
    private var p1: Player!
    private var p2: Player!
    private var score = (p1: 0, p2: 0)
    private var buttonGrid: [[UIButton]] = []
    private var winLayer: CAShapeLayer?

    // MARK: - Life-cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        guard let brain = gameBrain else { return }
        configureUI(with: brain)
        setupBoardGrid()
    }

    // MARK: - UI kurulumu
    private func configureUI(with brain: GameBoardBrain) {
        p1 = brain.player1
        p2 = brain.player2

        player1Avatar.image = p1.avatar
        player1Name.text    = p1.name
        player1Symbol.text  = p1.symbol
        player1Score.text   = "\(score.p1)"

        player2Avatar.image = p2.avatar
        player2Name.text    = p2.name
        player2Symbol.text  = p2.symbol
        player2Score.text   = "\(score.p2)"

        gameBrain.currentPlayer = p1
        player1Symbol.textColor = .systemRed
        player2Symbol.textColor = .white
    }

    private func setupBoardGrid() {
        let rows = gameBrain.gameBoard.rows
        let cols = gameBrain.gameBoard.cols

        let vStack = UIStackView()
        vStack.axis = .vertical
        vStack.distribution = .fillEqually
        vStack.translatesAutoresizingMaskIntoConstraints = false
        boardView.addSubview(vStack)

        NSLayoutConstraint.activate([
            vStack.topAnchor     .constraint(equalTo: boardView.topAnchor),
            vStack.bottomAnchor  .constraint(equalTo: boardView.bottomAnchor),
            vStack.leadingAnchor .constraint(equalTo: boardView.leadingAnchor),
            vStack.trailingAnchor.constraint(equalTo: boardView.trailingAnchor)
        ])

        for r in 0..<rows {
            var rowBtns: [UIButton] = []
            let hStack = UIStackView()
            hStack.axis = .horizontal
            hStack.distribution = .fillEqually
            vStack.addArrangedSubview(hStack)

            for c in 0..<cols {
                let b = UIButton(type: .custom)
                b.tag = r * 100 + c
                b.setImage(UIImage(named: "border3"), for: .normal)
                b.addTarget(self, action: #selector(cellTapped(_:)), for: .touchUpInside)
                hStack.addArrangedSubview(b)
                rowBtns.append(b)
            }
            buttonGrid.append(rowBtns)
        }
    }

    // MARK: - Hücre tıklaması
    @objc private func cellTapped(_ sender: UIButton) {
        let row = sender.tag / 100
        let col = sender.tag % 100

        // İnsan hamlesi + (varsa) bot hamlesi
        gameBrain.makeMove(row: row, col: col) { [weak self] result in
            self?.handleMoveResult(result)
        }

        // Tıklanan hücrenin görselini hemen değiştir
        let imgName = gameBrain.gameBoard.grid[row][col].gridSymbolIcon
        sender.setImage(UIImage(named: imgName), for: .normal)
    }

    // MARK: - Hamle sonucunu işle
    private func handleMoveResult(_ result: GameBoardBrain.MoveResult) {
        switch result {

        case let .win(winner, coords):
            if winner.symbol == p1.symbol { score.p1 += 1 }
            else                          { score.p2 += 1 }
            configureUI(with: gameBrain)
            drawWinLine(with: coords)

            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [weak self] in
                guard let self = self else { return }
                self.winLayer?.removeFromSuperlayer()

                if self.score.p1 == 3 || self.score.p2 == 3 {
                    let champ = (self.score.p1 == 3) ? self.p1 : self.p2
                    self.performSegue(withIdentifier: "showWinner", sender: champ)
                } else {
                    self.resetBoardForNextRound()
                }
            }

        case .draw:
            let alert = UIAlertController(title: "Berabere!", message: nil, preferredStyle: .alert)
            present(alert, animated: true)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
                alert.dismiss(animated: true)
                self?.resetBoardForNextRound()
            }

        case .continue:
            // Sıra değişti → etiket renklerini güncelle
            if gameBrain.currentPlayer.symbol == p1.symbol {
                player1Symbol.textColor = .systemRed
                player2Symbol.textColor = .white
            } else {
                player2Symbol.textColor = .systemRed
                player1Symbol.textColor = .white
            }
            // Bot hamlesi varsa eksik görselleri güncelle
            refreshAllButtons()
        }
    }

    // MARK: - Kazanan çizgisi
    private func drawWinLine(with coords: [(Int,Int)]) {
        guard coords.count >= 2 else { return }
        let startBtn = buttonGrid[coords.first!.0][coords.first!.1]
        let endBtn   = buttonGrid[coords.last!.0][coords.last!.1]

        let start = boardView.convert(startBtn.center, from: startBtn.superview)
        let end   = boardView.convert(endBtn.center,   from: endBtn.superview)

        let p = UIBezierPath()
        p.move(to: start); p.addLine(to: end)

        let layer = CAShapeLayer()
        layer.path = p.cgPath
        layer.lineWidth = 6
        layer.strokeColor = UIColor.systemYellow.cgColor
        layer.lineCap = .round
        boardView.layer.addSublayer(layer)
        winLayer = layer

        let anim = CABasicAnimation(keyPath: "strokeEnd")
        anim.fromValue = 0; anim.toValue = 1
        anim.duration  = 0.3
        layer.add(anim, forKey: "line")
    }

    // MARK: - Yardımcılar
    private func refreshAllButtons() {
        for r in 0..<buttonGrid.count {
            for c in 0..<buttonGrid[r].count {
                let imgName = gameBrain.gameBoard.grid[r][c].gridSymbolIcon
                buttonGrid[r][c].setImage(UIImage(named: imgName), for: .normal)
            }
        }
    }

    private func resetBoardForNextRound() {
        gameBrain.gameBoard.reset()
        for row in buttonGrid {
            for btn in row { btn.setImage(UIImage(named: "border3"), for: .normal) }
        }
        gameBrain.currentPlayer = p1
        player1Symbol.textColor = .systemRed
        player2Symbol.textColor = .white
    }

    private func fullReset() {
        score = (0,0)
        player1Score.text = "0"; player2Score.text = "0"
        resetBoardForNextRound()
    }

    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showWinner",
           let winVC  = segue.destination as? WinnerViewController,
           let winner = sender as? Player {
            winVC.winner   = winner
            winVC.onReplay = { [weak self] in self?.fullReset() }
        }
    }

    // MARK: - Çıkış
    @IBAction func kapat(_ sender: UIButton) { dismiss(animated: true) }
}
