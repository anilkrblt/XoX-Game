//
//  ViewController.swift
//  XoX Game
//
//  Created by Trakya4 on 10.05.2025.
//

import UIKit

class MenuViewController: UIViewController {
    
    var gameType : String = "Tek Oyuncu"
    
    //player 1
    var player1Name : String = "Player 1"
    var player1Symbol : String = "X"
    var player1Icon: String = "x7"
    var player1Avatar: String = "avatar1"
    
    //player 2
    var player2Name : String = "Player 2"
    var player2Symbol: String = "O"
    var player2Icon : String = "o7"
    var player2Avatar :String = "avatar2"
    

    
    @IBOutlet weak var player1SymbolBtn: UIButton!
    @IBOutlet weak var player2SymbolBtn: UIButton!
    
    
    
    @IBOutlet weak var satirLabel: UILabel!
    @IBOutlet weak var sutunLabel: UILabel!
    
    
    @IBOutlet weak var gridLabel: UILabel!
    
    
    var satirSayisi : Int = 3
    var sutunSayisi : Int = 3
    
    @IBOutlet weak var player2View: UIStackView!

    @IBOutlet weak var player1SymbolChoose: UISegmentedControl!
    @IBOutlet weak var player2SymbolChoose: UISegmentedControl!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        player2SymbolChoose.selectedSegmentIndex = 1
        player2View.isHidden = true
        player2Avatar = "avatar6"
       
        
        
        
      
    }
    
    
 // tek veya iki kişilik oyun oynamak için
    @IBAction func oyunTuruAyarla(_ sender: UISegmentedControl) {
        
        let selectedIndex = sender.selectedSegmentIndex
        gameType = sender.titleForSegment(at: selectedIndex) ?? "Çok Oyunculu"
        player2View.isHidden = !player2View.isHidden
        print(gameType)
        
    }
    
    
// player 1
    @IBAction func setPlayer1Name(_ sender: UITextField) {
        player1Name = sender.text ?? ""
    }
    
    
    @IBAction func player1Symbol(_ sender: UISegmentedControl) {
        let selectedIndex = sender.selectedSegmentIndex
        player1Symbol = sender.titleForSegment(at: selectedIndex) ?? ""
        
        if (player1Symbol == "O")
        {
            player1SymbolBtn.setImage(UIImage(named: "o7"), for: .normal)
            player2SymbolBtn.setImage(UIImage(named: "x7"), for: .normal)
            player1Icon  = "o7"   // <-- EKLE
            player2Icon  = "x7"
            player2Symbol = "X"
        }
        if (player1Symbol == "X")
        {
            player1SymbolBtn.setImage(UIImage(named: "x7"), for: .normal)
            player2SymbolBtn.setImage(UIImage(named: "o7"), for: .normal)
            player1Icon  = "x7"   // <-- EKLE
            player2Icon  = "o7"
            player2Symbol = "O"
        }

        
        
        if (selectedIndex == 1){
            player2SymbolChoose.selectedSegmentIndex = 0
        }
        if (selectedIndex == 0){
            player2SymbolChoose.selectedSegmentIndex = 1
        }
    }
    
    
    @IBAction func player1SymbolIcon(_ sender: UIButton) {

        let prefix = (player1Symbol == "X") ? "x" : "o"
        let picker = AvatarPickerViewController()
        picker.icons = (1...8).map { "\(prefix)\($0)" }

        picker.didSelect = { [weak self] imgName in
            sender.setImage(UIImage(named: imgName), for: .normal)
            self?.player1Icon = imgName
        }

        picker.modalPresentationStyle = .pageSheet
        present(picker, animated: true)
    }


    
    
    @IBAction func player1Avatar(_ sender: UIButton) {

        
        let picker = AvatarPickerViewController()
        picker.icons = ["avatar1", "avatar2", "avatar3", "avatar4", "avatar5", "avatar6"]


        picker.didSelect = { [weak self] imgName in
            sender.setImage(UIImage(named: imgName), for: .normal)
            self?.player1Avatar = imgName
       
        }


        picker.modalPresentationStyle = .pageSheet
        present(picker, animated: true)
    }
    
    
    
    
    
    
    
    
    
    
    
    
    @IBAction func setPlayer2Name(_ sender: UITextField) {
        player2Name = sender.text ?? ""
    }
    
    

    @IBAction func player2Symbol(_ sender: UISegmentedControl) {
        let selectedIndex = sender.selectedSegmentIndex
        player2Symbol  = sender.titleForSegment(at: selectedIndex) ?? ""
        
        if (player2Symbol == "O")
        {
            player1SymbolBtn.setImage(UIImage(named: "x7"), for: .normal)
            player2SymbolBtn.setImage(UIImage(named: "o7"), for: .normal)
            player1Icon  = "x7"   // <-- EKLE
            player2Icon  = "o7"
            player1Symbol = "X"
        }
        
        if (player2Symbol == "X")
        {
            player1SymbolBtn.setImage(UIImage(named: "o7"), for: .normal)
            player2SymbolBtn.setImage(UIImage(named: "x7"), for: .normal)
            player1Icon  = "o7"   // <-- EKLE
            player2Icon  = "x7"  
            player1Symbol = "O"
        }
        
        if (selectedIndex == 1){
            player1SymbolChoose.selectedSegmentIndex = 0
            
        }
        if (selectedIndex == 0){
            player1SymbolChoose.selectedSegmentIndex = 1
            
        }
        
    }
    

    @IBAction func player2SymbolIcon(_ sender: UIButton) {

      
        let prefix = (player2Symbol == "O") ? "o" : "x"

 
        let picker = AvatarPickerViewController()
        picker.icons = (1...8).map { "\(prefix)\($0)" }

      
        picker.didSelect = { [weak self] imgName in
            sender.setImage(UIImage(named: imgName), for: .normal)
            self?.player2Icon = imgName
        }

        picker.modalPresentationStyle = .pageSheet
        present(picker, animated: true)
    }
    
 
    
    
    @IBAction func player2Avatar(_ sender: UIButton) {

   
        let picker = AvatarPickerViewController()
        picker.icons = ["avatar1", "avatar2", "avatar3", "avatar4", "avatar5", "avatar6"]

     
        picker.didSelect = { [weak self] imgName in
            sender.setImage(UIImage(named: imgName), for: .normal)
            self?.player2Avatar = imgName
       
        }

        picker.modalPresentationStyle = .pageSheet
        present(picker, animated: true)
    }

    
    
    
    
    
    
    @IBAction func satirSayisiArtir(_ sender: UIButton) {
        if satirSayisi < 6{
            satirSayisi += 1
            satirLabel.text = String(satirSayisi)
            gridLabel.text =  String("\(satirSayisi)x\(sutunSayisi)")
            
        }

        
    }
    
    
    
    @IBAction func satirSayisiAzalt(_ sender: UIButton) {

        
        if satirSayisi > 3 {
            satirSayisi -= 1
            satirLabel.text = String(satirSayisi)
            gridLabel.text =  String("\(satirSayisi)x\(sutunSayisi)")
        }
    }
    
    
    
    @IBAction func sutunSayisiArtir(_ sender: UIButton) {
        if sutunSayisi < 6{
            sutunSayisi += 1
            sutunLabel.text = String(sutunSayisi)
            gridLabel.text =  String("\(satirSayisi)x\(sutunSayisi)")
        }

        
    }
    
    
    @IBAction func sutunSayisiAzalt(_ sender: UIButton) {
        if sutunSayisi > 3 {
            sutunSayisi -= 1
            sutunLabel.text = String(sutunSayisi)
            gridLabel.text =  String("\(satirSayisi)x\(sutunSayisi)")
        }
        
        
    }
    
   
    

    @IBAction func oyunuBaslat(_ sender: UIButton) {
        let singlePlayer = (gameType == "Tek Oyuncu")

            // 1. gerçek oyuncu
        let p1 = Player(symbol: player1Symbol,
                        name:   player1Name,
                        isBot:  false,
                        symbolIconName: player1Icon,
                        avatarName:     player1Avatar)

        let p2 = Player(symbol: player2Symbol,
                        name:   singlePlayer ? "Bot" : player2Name,
                        isBot:  singlePlayer,
                        symbolIconName: player2Icon,
                        avatarName:     player2Avatar)
         // <-- bot bilgisi

            let board = GameBoard(rows: satirSayisi, cols: sutunSayisi)

            let brain = GameBoardBrain(player1: p1,
                                       player2: p2,
                                       isTwoPlayer: !singlePlayer,
                                       currentPlayer: p1,
                                       gameBoard: board)

            performSegue(withIdentifier: "toGame", sender: brain)
    
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toGame",
           let gameVC = segue.destination as? GameViewController,
           let brain  = sender as? GameBoardBrain {
            gameVC.gameBrain = brain
        }
    }



}











