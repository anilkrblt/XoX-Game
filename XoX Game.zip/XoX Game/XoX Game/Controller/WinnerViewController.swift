import UIKit

class WinnerViewController: UIViewController {

    // MARK: - Model
    var winner:   Player!
    var onReplay: (() -> Void)?     // ← GameVC’den gelecek kapanış

    // MARK: - IBOutlets
    @IBOutlet weak var winnerAvatar: UIImageView!
    @IBOutlet weak var winnerName:   UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        guard let p = winner else { return }

        winnerAvatar.image = p.avatar
        winnerName.text    = "\(p.name) kazandı!"
        startSymbolRain(symbolImage: p.symbolIcon ?? UIImage())
    }

    // 🔄 Tekrar oyna
    @IBAction func tekrarOyna(_ sender: UIButton) {
        onReplay?()                                      // ◀️ GameVC’ye “reset” sinyali
        if let nav = navigationController {
            nav.popViewController(animated: true)        // push ise
        } else {
            dismiss(animated: true)                      // modal ise
        }
    }

    // ⬅️ Ana menü
    @IBAction func anaMenuyeDon(_ sender: UIButton) {
        if let nav = navigationController {
            nav.popToRootViewController(animated: true)
        } else {
            presentingViewController?
                .presentingViewController?
                .dismiss(animated: true)
        }
    }
}

// MARK: - Yağmur efekti (değişmedi)
private extension WinnerViewController {
    func startSymbolRain(symbolImage: UIImage) {
        let emitter = CAEmitterLayer()
        emitter.emitterPosition = CGPoint(x: view.bounds.midX, y: -20)
        emitter.emitterShape    = .line
        emitter.emitterSize     = CGSize(width: view.bounds.width, height: 1)

        let cell = CAEmitterCell()
        cell.contents      = symbolImage.cgImage
        cell.birthRate     = 6
        cell.lifetime      = 6
        cell.velocity      = 120
        cell.velocityRange = 60
        cell.scale         = 0.25
        cell.scaleRange    = 0.1
        cell.spinRange     = .pi
        cell.yAcceleration = 80

        emitter.emitterCells = [cell]
        view.layer.addSublayer(emitter)
    }
}
