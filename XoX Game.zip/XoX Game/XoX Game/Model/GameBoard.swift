import UIKit

// MARK: - GameBoard
class GameBoard {

    // MARK: Stored data
    let rows: Int
    let cols: Int
    private let emptySymbol: String
    private(set) var grid: [[GridItem]]

    // MARK: Init
    init(rows: Int, cols: Int, defaultSymbol: String = "border3") {
        self.rows = rows
        self.cols = cols
        self.emptySymbol = defaultSymbol
        self.grid = (0..<rows).map { r in
            (0..<cols).map { c in
                GridItem(colIdx: c,
                         rowIdx: r,
                         gridSymbolIcon: defaultSymbol,
                         isEmpty: true)
            }
        }
    }

    // MARK: Public helpers
    func reset() {
        for r in 0..<rows {
            for c in 0..<cols {
                grid[r][c] = GridItem(colIdx: c,
                                      rowIdx: r,
                                      gridSymbolIcon: emptySymbol,
                                      isEmpty: true)
            }
        }
    }

    /// Tek hamle yap + kazanma kontrolü
    /// - Returns: (`kazandı mı`, **kazanan hücre koordinatları**)
    @discardableResult
    func playerMoveAndCheck(row: Int,
                            column: Int,
                            player: Player,
                            winLength: Int? = nil) -> (Bool, [(Int,Int)]) {

        guard grid[row][column].isEmpty else { return (false, []) }

        grid[row][column] = GridItem(colIdx: column,
                                     rowIdx: row,
                                     gridSymbolIcon: player.symbolIconName,
                                     isEmpty: false)

        let coords = winningCoords(from: row,
                                   col: column,
                                   symbol: player.symbolIconName,
                                   winLength: winLength)

        return (!coords.isEmpty, coords)
    }

    /// Tahta tamamen dolu mu?
    var isFull: Bool {
        !grid.flatMap { $0 }.contains { $0.isEmpty }
    }
}

// MARK: - Kazanma hesaplamaları
private extension GameBoard {

    func winningCoords(from r: Int,
                       col c: Int,
                       symbol: String,
                       winLength: Int?) -> [(Int,Int)] {

        let need = winLength ?? min(rows, cols)
        let dirs = [(0,1), (1,0), (1,1), (1,-1)]   // ↔︎  ↕︎  ↘︎  ↗︎

        for (dr, dc) in dirs {
            var line = [(Int,Int)]([(r, c)])
            line += collect(r, c,  dr,  dc, symbol)
            line += collect(r, c, -dr, -dc, symbol)

            if line.count >= need {
                // merkez–uç sırası önemli; sort tek çizgi için
                return line.sorted { $0.0*cols + $0.1 < $1.0*cols + $1.1 }
            }
        }
        return []
    }

    /// Tek yönde aynı sembolleri toplar
    func collect(_ r0: Int, _ c0: Int,
                 _ dr: Int, _ dc: Int,
                 _ sym: String) -> [(Int,Int)] {

        var r = r0 + dr, c = c0 + dc
        var arr: [(Int,Int)] = []

        while (0..<rows).contains(r),
              (0..<cols).contains(c),
              grid[r][c].gridSymbolIcon == sym {
            arr.append((r, c))
            r += dr; c += dc
        }
        return arr
    }
}
