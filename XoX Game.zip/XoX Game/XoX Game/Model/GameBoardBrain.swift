//
//  GameBoardBrain.swift
//

import UIKit

/// Oyun akışını yöneten sınıf
class GameBoardBrain {

    // MARK: - Stored state
    let player1: Player
    let player2: Player
    let isTwoPlayer: Bool            // true  → iki insan / false → tek oyuncu + bot
    var currentPlayer: Player
    private(set) var gameBoard: GameBoard

    /// Bot hamlesi görsel olarak “düşünsün” diye küçük gecikme
    private let botDelay: TimeInterval = 0.4

    // MARK: - Init
    init(player1: Player,
         player2: Player,
         isTwoPlayer: Bool,
         currentPlayer: Player,
         gameBoard: GameBoard) {

        self.player1       = player1
        self.player2       = player2
        self.isTwoPlayer   = isTwoPlayer
        self.currentPlayer = currentPlayer
        self.gameBoard     = gameBoard
    }

    // MARK: - Move result
    enum MoveResult {
        case win(player: Player, coords: [(Int,Int)])
        case draw
        case `continue`
    }

    // MARK: - Public API
    /// Kullanıcı bir hücreye dokunduğunda çağır – sonucu completion’da döner
    func makeMove(row: Int, col: Int,
                  onFinish: @escaping (MoveResult) -> Void) {

        // 1) Önce insan hamlesi
        let result = internalMove(row: row, col: col)
        onFinish(result)
        guard case .continue = result else { return }

        // 2) Bot devreye girecek mi?
        if !isTwoPlayer, currentPlayer.isBot {
            DispatchQueue.main.asyncAfter(deadline: .now() + botDelay) {
                self.playBot(onFinish: onFinish)
            }
        }
    }

    // MARK: - Private helpers
    /// Bot – rastgele boş hücre seçer
    private func playBot(onFinish: @escaping (MoveResult) -> Void) {
        guard let (r, c) = randomEmptyCell() else { return }
        let result = internalMove(row: r, col: c)
        onFinish(result)
    }

    /// Gerçek hamleyi yaptırır ve sonucu döner
    @discardableResult
    private func internalMove(row: Int, col: Int) -> MoveResult {

        // hamle + kazanç koordinatlarını al
        let (didWin, coords) = gameBoard.playerMoveAndCheck(row: row,
                                                            column: col,
                                                            player: currentPlayer)

        if didWin       { return .win(player: currentPlayer, coords: coords) }
        if gameBoard.isFull { return .draw }

        // Sırayı değiştir, devam et
        currentPlayer = (currentPlayer.symbol == player1.symbol) ? player2 : player1
        return .continue
    }

    /// Tahtadaki boş hücrelerden rastgele birini seç
    private func randomEmptyCell() -> (Int, Int)? {
        var empties: [(Int,Int)] = []
        for r in 0..<gameBoard.rows {
            for c in 0..<gameBoard.cols where gameBoard.grid[r][c].isEmpty {
                empties.append((r, c))
            }
        }
        return empties.randomElement()
    }
}
