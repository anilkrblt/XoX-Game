struct GridItem {
    
    let colIdx: Int
    let rowIdx: Int
    
    let gridSymbolIcon: String
    let isEmpty: Bool
    
}
