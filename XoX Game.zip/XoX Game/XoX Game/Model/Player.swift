import UIKit

struct Player {
    
    let symbol: String
    let name: String
    let isBot: Bool 
    
    let symbolIconName: String    
    let avatarName:     String

    var symbolIcon: UIImage? { UIImage(named: symbolIconName) }
    var avatar:     UIImage? { UIImage(named: avatarName) }
    

    
}
